// 项目共享的pinia实例， 在非vue文件中调用store时需要显示传进去
export default createPinia()