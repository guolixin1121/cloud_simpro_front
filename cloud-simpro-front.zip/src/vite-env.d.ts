/// <reference types="vite/client" />

declare const process: NodeJS.Process
