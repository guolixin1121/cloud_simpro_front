<template>
  <div>
    <div class="title">安全性评测</div>

    <table class="top table">
      <tr>
        <td>安全评测总计<span class="value">7</span>项</td>
        <td>安全评测总计<span class="value">7</span>项</td>
        <td>安全评测总计<span class="value">7</span>项</td>
        <td>安全评测总计<span class="value">7</span>项</td>
      </tr>
    </table>

    <div class="sub-title">测试项</div>

    <table class="table">
      <tr>
        <td>预期碰撞时间<span class="value">7</span>项</td>
        <td>安全评测总计<span class="value">7</span>项</td>
        <td>安全评测总计<span class="value">7</span>项</td>
      </tr>
      <tr>
        <td>安全评测总计<span class="value">7</span>项</td>
        <td>安全评测总计<span class="value">7</span>项</td>
        <td>安全评测总计<span class="value">7</span>项</td>
      </tr>
      <tr>
        <td>安全评测总计<span class="value">7</span>项</td>
        <td>安全评测总计<span class="value">7</span>项</td>
        <td>安全评测总计<span class="value">7</span>项</td>
      </tr>
    </table>

    <div class="sub-title">未通过项目</div>
    <table class="table">
      <thead>
        <tr>
          <th>序号</th>
          <th>场景</th>
          <th>问题项</th>
        </tr>
      </thead>
      <tr>
        <td>预期碰撞时间<span class="value">7</span>项</td>
        <td>安全评测总计<span class="value">7</span>项</td>
        <td>安全评测总计<span class="value">7</span>项</td>
      </tr>
      <tr>
        <td>安全评测总计<span class="value">7</span>项</td>
        <td>安全评测总计<span class="value">7</span>项</td>
        <td>安全评测总计<span class="value">7</span>项</td>
      </tr>
      <tr>
        <td>安全评测总计<span class="value">7</span>项</td>
        <td>安全评测总计<span class="value">7</span>项</td>
        <td>安全评测总计<span class="value">7</span>项</td>
      </tr>
    </table>
  </div>
</template>

<style lang="less" scoped>
.top {
  td { padding-left: 42px; }
}
</style>