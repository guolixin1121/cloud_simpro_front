# 封装a-upload
上传限定为单文件的Upload组件