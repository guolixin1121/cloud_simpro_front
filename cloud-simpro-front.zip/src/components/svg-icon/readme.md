# 自定义SVG ICON
已全局引入，可直接使用

## 属性
1. icon
ICON名称，对应assets/icons目录下的文件名

## demo
``` html
<SvgIcon icon="online"></SvgIcon>
```